# CodeIgniter 4 Third-Party API Machine Test

This package contains copy-paste-ready CodeIgniter 4 files demonstrating:

- GET third-party API
- POST third-party API
- Bearer token authentication
- API-key authentication
- jQuery AJAX
- JSON responses
- Server-side validation
- HTTP status-code handling
- Database migration
- Model
- Saving successful API results locally
- Service class architecture
- Error logging
- XSS-safe output

## 1. Copy files

Copy the contents of `app/` into your CodeIgniter 4 project's `app/` directory.

Do not replace your existing `app/Config/Routes.php`.

Open `app/Config/Routes.php` and add the routes from:

`app/Config/Routes.php.add`

## 2. Configure .env

Copy the required database and API settings from `.env.example_api` into your project's `.env`.

Replace:

THIRD_PARTY_API_URL = https://example.com/api
THIRD_PARTY_API_TOKEN = your_real_bearer_token_here

with the actual values provided by the API provider.

Never commit real API tokens to Git.

## 3. Create database

Create a MySQL database, for example:

codeigniter_db

Update the database settings in `.env`.

## 4. Run migration

From the CodeIgniter project root:

php spark migrate

## 5. Test country GET API

Open:

/country

Enter a country such as:

India

The browser sends AJAX to:

POST /country/search

The controller calls:

https://restcountries.com/v3.1/name/India

This public API does not require a token.

## 6. Test authenticated POST API

Open:

/customer/create

The form sends an AJAX POST request to:

POST /customer/store

The controller validates the request.

The service sends JSON to:

THIRD_PARTY_API_URL/customers

with:

Authorization: Bearer YOUR_TOKEN

After a successful 2xx response, the customer is also saved locally.

IMPORTANT:

`https://example.com/api` is only a placeholder. Replace it with the real API supplied during the machine test.

## 7. API-key example

The service also contains:

getWithApiKey()

It sends:

X-API-KEY: YOUR_API_KEY

Use this pattern if the machine-test API uses API-key authentication instead of Bearer authentication.

## 8. Useful interview flow

Browser
  -> jQuery AJAX
  -> CodeIgniter Route
  -> Controller
  -> Validation
  -> Service
  -> Third-party API
  -> JSON response
  -> Controller
  -> Database
  -> AJAX response

## 9. Important status codes

200 = OK
201 = Created
400 = Bad Request
401 = Unauthorized
403 = Forbidden
404 = Not Found
422 = Validation error
429 = Too Many Requests
500 = Server error
503 = Service unavailable

## 10. Security points

- Keep API tokens in `.env`.
- Do not expose secret tokens in JavaScript.
- Validate input on the server.
- Escape output.
- Use HTTPS for production API calls.
- Log technical errors but do not return sensitive exception details to users.
- Use `http_errors => false` when you want to inspect non-2xx API responses yourself.
