<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Customers - CodeIgniter 4</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 900px; margin: 40px auto; padding: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background: #f5f5f5; }
        a { display: inline-block; margin-bottom: 15px; }
    </style>
</head>
<body>

<h1>Customers</h1>

<a href="<?= base_url('customer/create') ?>">+ Create Customer</a>

<table>
    <thead>
    <tr>
        <th>ID</th>
        <th>External ID</th>
        <th>Name</th>
        <th>Email</th>
        <th>Created</th>
    </tr>
    </thead>

    <tbody>
    <?php foreach ($customers as $customer): ?>
        <tr>
            <td><?= esc($customer['id']) ?></td>
            <td><?= esc($customer['external_id']) ?></td>
            <td><?= esc($customer['name']) ?></td>
            <td><?= esc($customer['email']) ?></td>
            <td><?= esc($customer['created_at']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

</body>
</html>
