<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Customer - CodeIgniter 4</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; max-width: 700px; margin: 40px auto; padding: 20px; }
        label { display: block; margin-top: 15px; }
        input { width: 100%; max-width: 450px; padding: 10px; box-sizing: border-box; }
        button { margin-top: 20px; padding: 10px 18px; cursor: pointer; }
        .error { color: #b00020; margin-top: 15px; }
        .success { color: #087f23; margin-top: 15px; }
    </style>
</head>
<body>

<h1>Create Customer</h1>

<form id="customerForm">
    <?= csrf_field() ?>

    <label for="name">Name</label>
    <input type="text" id="name" name="name">

    <label for="email">Email</label>
    <input type="email" id="email" name="email">

    <button type="submit">Create Customer</button>
</form>

<div id="message"></div>
<div id="errors"></div>

<script>
$('#customerForm').on('submit', function (e) {
    e.preventDefault();

    $('#message').html('');
    $('#errors').html('');

    $.ajax({
        url: '<?= base_url('customer/store') ?>',
        type: 'POST',
        dataType: 'json',
        data: $(this).serialize(),
        success: function (response) {
            if (response.status) {
                $('#message').html(
                    '<p class="success">' + response.message + '</p>'
                );

                $('#customerForm')[0].reset();

                if (response.data && response.data.local_id) {
                    $('#message').append(
                        '<p>Local customer ID: ' + response.data.local_id + '</p>'
                    );
                }

                return;
            }

            $('#message').html(
                '<p class="error">' + (response.message || 'Request failed.') + '</p>'
            );
        },
        error: function (xhr) {
            let response = xhr.responseJSON;

            if (response && response.errors) {
                let html = '<ul class="error">';

                $.each(response.errors, function (field, message) {
                    html += '<li>' + $('<div>').text(message).html() + '</li>';
                });

                html += '</ul>';
                $('#errors').html(html);
            } else {
                $('#message').html(
                    '<p class="error">' +
                    ((response && response.message) || 'Something went wrong.') +
                    '</p>'
                );
            }
        }
    });
});
</script>

</body>
</html>
