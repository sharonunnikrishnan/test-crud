<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Country API - CodeIgniter 4</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 40px auto; padding: 20px; }
        input, button { padding: 10px; }
        input { width: 280px; }
        button { cursor: pointer; }
        #message { margin-top: 20px; }
        .result { margin-top: 20px; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }
        img { max-width: 160px; }
    </style>
</head>
<body>

<h1>Country API Search</h1>

<form id="countryForm">
    <input type="text" id="country" name="country" placeholder="Enter country">
    <button type="submit">Search</button>
</form>

<div id="message"></div>
<div id="result"></div>

<script>
function escapeHtml(value) {
    return $('<div>').text(value ?? '').html();
}

$('#countryForm').on('submit', function (e) {
    e.preventDefault();

    $('#message').html('Loading...');
    $('#result').html('');

    $.ajax({
        url: '<?= base_url('country/search') ?>',
        type: 'POST',
        dataType: 'json',
        data: {
            country: $('#country').val()
        },
        success: function (response) {
            if (!response.status) {
                $('#message').html('<p>' + escapeHtml(response.message) + '</p>');
                return;
            }

            const data = response.data;

            $('#message').html('<p>API request successful.</p>');

            $('#result').html(`
                <div class="result">
                    <h2>${escapeHtml(data.name)}</h2>
                    <p><strong>Official:</strong> ${escapeHtml(data.official_name)}</p>
                    <p><strong>Capital:</strong> ${escapeHtml(data.capital)}</p>
                    <p><strong>Region:</strong> ${escapeHtml(data.region)}</p>
                    <p><strong>Population:</strong> ${Number(data.population).toLocaleString()}</p>
                    <p><strong>Currency:</strong> ${escapeHtml(data.currency)}</p>
                    ${data.flag ? `<img src="${escapeHtml(data.flag)}" alt="Flag">` : ''}
                </div>
            `);
        },
        error: function (xhr) {
            let message = 'Something went wrong.';

            if (xhr.responseJSON && xhr.responseJSON.message) {
                message = xhr.responseJSON.message;
            }

            $('#message').html('<p>' + escapeHtml(message) + '</p>');
        }
    });
});
</script>

</body>
</html>
