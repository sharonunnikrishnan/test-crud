<?php

namespace App\Services;

class ThirdPartyApiService
{
    protected $client;

    public function __construct()
    {
        $this->client = \Config\Services::curlrequest([
            'timeout' => 10,
            'http_errors' => false,
        ]);
    }

    public function createCustomer(array $data): array
    {
        $token = env('THIRD_PARTY_API_TOKEN');
        $baseUrl = rtrim((string) env('THIRD_PARTY_API_URL'), '/');

        if (!$baseUrl || !$token) {
            throw new \RuntimeException('Third-party API URL/token is not configured.');
        }

        $response = $this->client->post($baseUrl . '/customers', [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
            ],
            'json' => $data,
        ]);

        return [
            'statusCode' => $response->getStatusCode(),
            'data' => json_decode($response->getBody(), true),
        ];
    }

    public function getUsers(): array
    {
        $token = env('THIRD_PARTY_API_TOKEN');
        $baseUrl = rtrim((string) env('THIRD_PARTY_API_URL'), '/');

        $response = $this->client->get($baseUrl . '/users', [
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Accept' => 'application/json',
            ],
        ]);

        return [
            'statusCode' => $response->getStatusCode(),
            'data' => json_decode($response->getBody(), true),
        ];
    }

    public function getWithApiKey(string $endpoint): array
    {
        $baseUrl = rtrim((string) env('THIRD_PARTY_API_URL'), '/');
        $apiKey = env('THIRD_PARTY_API_KEY');

        $response = $this->client->get($baseUrl . '/' . ltrim($endpoint, '/'), [
            'headers' => [
                'X-API-KEY' => $apiKey,
                'Accept' => 'application/json',
            ],
        ]);

        return [
            'statusCode' => $response->getStatusCode(),
            'data' => json_decode($response->getBody(), true),
        ];
    }
}
