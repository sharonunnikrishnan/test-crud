<?php

namespace App\Controllers;

class CountryController extends BaseController
{
    public function index()
    {
        return view('country/index');
    }

    public function search()
    {
        $country = trim((string) $this->request->getPost('country'));

        if ($country === '') {
            return $this->response->setStatusCode(422)->setJSON([
                'status' => false,
                'message' => 'Country name is required.',
            ]);
        }

        try {
            $client = \Config\Services::curlrequest([
                'timeout' => 10,
                'http_errors' => false,
            ]);

            $url = 'https://restcountries.com/v3.1/name/' . rawurlencode($country);
            $response = $client->get($url);

            $statusCode = $response->getStatusCode();
            $body = json_decode($response->getBody(), true);

            if ($statusCode !== 200 || !is_array($body) || empty($body)) {
                return $this->response->setStatusCode($statusCode ?: 500)->setJSON([
                    'status' => false,
                    'message' => $statusCode === 404
                        ? 'Country not found.'
                        : 'Country API request failed.',
                ]);
            }

            $countryData = $body[0];

            return $this->response->setJSON([
                'status' => true,
                'data' => [
                    'name' => $countryData['name']['common'] ?? null,
                    'official_name' => $countryData['name']['official'] ?? null,
                    'capital' => $countryData['capital'][0] ?? null,
                    'region' => $countryData['region'] ?? null,
                    'population' => $countryData['population'] ?? 0,
                    'currency' => array_key_first($countryData['currencies'] ?? []),
                    'flag' => $countryData['flags']['png'] ?? null,
                ],
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'Country API error: {message}', [
                'message' => $e->getMessage(),
            ]);

            return $this->response->setStatusCode(500)->setJSON([
                'status' => false,
                'message' => 'Unable to connect to third-party API.',
            ]);
        }
    }
}
