<?php

namespace App\Controllers;

use App\Models\CustomerModel;
use App\Services\ThirdPartyApiService;

class CustomerController extends BaseController
{
    public function create()
    {
        return view('customer/create');
    }

    public function store()
    {
        $rules = [
            'name' => 'required|min_length[2]|max_length[100]',
            'email' => 'required|valid_email|max_length[150]',
        ];

        if (!$this->validate($rules)) {
            return $this->response->setStatusCode(422)->setJSON([
                'status' => false,
                'message' => 'Validation failed.',
                'errors' => $this->validator->getErrors(),
            ]);
        }

        $data = [
            'name' => trim((string) $this->request->getPost('name')),
            'email' => trim((string) $this->request->getPost('email')),
        ];

        try {
            $apiService = new ThirdPartyApiService();
            $result = $apiService->createCustomer($data);

            if ($result['statusCode'] >= 200 && $result['statusCode'] < 300) {
                $apiData = is_array($result['data']) ? $result['data'] : [];

                $externalId = $apiData['id']
                    ?? $apiData['customer_id']
                    ?? $apiData['data']['id']
                    ?? null;

                $model = new CustomerModel();
                $model->insert([
                    'external_id' => $externalId,
                    'name' => $data['name'],
                    'email' => $data['email'],
                ]);

                return $this->response->setJSON([
                    'status' => true,
                    'message' => 'Customer sent to API and saved locally.',
                    'data' => [
                        'api_response' => $apiData,
                        'local_id' => $model->getInsertID(),
                    ],
                ]);
            }

            return $this->response->setStatusCode($result['statusCode'])->setJSON([
                'status' => false,
                'message' => 'Third-party API request failed.',
                'data' => $result['data'],
            ]);
        } catch (\Throwable $e) {
            log_message('error', 'Customer API error: {message}', [
                'message' => $e->getMessage(),
            ]);

            return $this->response->setStatusCode(500)->setJSON([
                'status' => false,
                'message' => 'Unable to connect to third-party API.',
            ]);
        }
    }

    public function index()
    {
        $model = new CustomerModel();

        return view('customer/index', [
            'customers' => $model->orderBy('id', 'DESC')->findAll(),
        ]);
    }
}
